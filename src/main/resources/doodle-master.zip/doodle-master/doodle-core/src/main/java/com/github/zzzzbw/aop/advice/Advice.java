package com.github.zzzzbw.aop.advice;

/**
 * 通知接口
 *
 * @author zzzzbw
 * @since 2018/6/20 17:39
 */
public interface Advice {
}
