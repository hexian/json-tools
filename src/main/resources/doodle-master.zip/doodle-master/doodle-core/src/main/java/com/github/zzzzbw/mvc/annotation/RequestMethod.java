package com.github.zzzzbw.mvc.annotation;

/**
 * http请求类型
 *
 * @author zzzzbw
 * @since 2018/5/24 18:06
 */
public enum RequestMethod {

    GET, POST
}
