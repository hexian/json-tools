package github.zzzzbw;


import com.github.zzzzbw.Doodle;

/**
 * @author zzzzbw
 * @since 2018/5/24 14:43
 */
public class App {

    public static void main(String[] args) {
        Doodle.run(App.class);
    }
}
